from .fast_chunker import *

__doc__ = fast_chunker.__doc__
if hasattr(fast_chunker, "__all__"):
    __all__ = fast_chunker.__all__